const today = new Intl.DateTimeFormat("bn-BD", {
  year:"numeric", month:"long", day:"numeric"
}).format(new Date());
document.getElementById("today").textContent = today;

const menuToggle = document.getElementById("menuToggle");
const menu = document.getElementById("menu");
menuToggle.addEventListener("click", () => menu.classList.toggle("open"));
document.querySelectorAll(".menu a").forEach(a => a.addEventListener("click", () => menu.classList.remove("open")));

const services = [
  "অসহায় সহায়তা","শিক্ষা সহায়তা","স্বাস্থ্যসেবা","সামাজিক উন্নয়ন",
  "দান","আবেদন","নোটিশ","সংবাদ"
];
const input = document.getElementById("searchInput");
const result = document.getElementById("searchResult");
function doSearch(){
  const q = input.value.trim();
  if(!q){ result.textContent = "অনুগ্রহ করে একটি বিষয় লিখুন।"; return; }
  const found = services.filter(x => x.includes(q));
  result.textContent = found.length ? `মিল পাওয়া গেছে: ${found.join(", ")}` : "এই নামে কোনো সেবা পাওয়া যায়নি।";
}
document.getElementById("searchBtn").addEventListener("click", doSearch);
input.addEventListener("keydown", e => { if(e.key === "Enter") doSearch(); });
